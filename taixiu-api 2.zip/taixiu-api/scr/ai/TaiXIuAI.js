cat > src/ai/TaiXiuAI.js << 'EOF'
// =====================================================
//      AI DỰ ĐOÁN TÀI XỈU - ĐỌC env.txt
// =====================================================

// Đọc file env.txt
const dotenv = require('dotenv');
dotenv.config({ path: './env.txt' });

const fs = require('fs');
const path = require('path');
const helpers = require('../utils/helpers');

class TaiXiuAI {
    constructor() {
        // Q-Learning params
        this.qTable = {};
        this.alpha = 0.1;
        this.gamma = 0.9;
        this.epsilon = 0.2;
        
        // Config - lấy từ env.txt hoặc dùng mặc định
        this.url = process.env.API_URL || 'https://wtxmd52.tele68.com/v1/txmd5/sessions?cp=R&cl=R&pf=web&at=182c61f07a70e3b61eb3dd1bad7f6c15';
        this.trained = false;
        
        // Lịch sử game
        this.historyFile = path.join(__dirname, '../../data/lichsu.json');
        this.history = [];
        this.loadHistory();
    }

    // ====== LƯU LỊCH SỬ ======
    loadHistory() {
        try {
            if (fs.existsSync(this.historyFile)) {
                const data = fs.readFileSync(this.historyFile, 'utf8');
                this.history = JSON.parse(data);
                console.log(`📂 Đã tải ${this.history.length} lịch sử game`);
            } else {
                this.saveHistory();
            }
        } catch (e) {
            console.log('⚠️ Không thể tải lịch sử, tạo mới');
            this.history = [];
            this.saveHistory();
        }
    }

    saveHistory() {
        try {
            const dir = path.dirname(this.historyFile);
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }
            fs.writeFileSync(this.historyFile, JSON.stringify(this.history, null, 2));
            console.log(`💾 Đã lưu ${this.history.length} kết quả game`);
        } catch (e) {
            console.error('❌ Lỗi lưu lịch sử:', e.message);
        }
    }

    // ====== LƯU KẾT QUẢ GAME ======
    addGameResult(session, dice, total, result, prediction, confidence) {
        const record = {
            id: this.history.length + 1,
            session: session,
            time: new Date().toISOString(),
            dice: dice,
            total: total,
            result: result,
            prediction: prediction,
            confidence: confidence,
            win: result === prediction
        };
        
        this.history.push(record);
        this.saveHistory();
        
        console.log(`📝 Game #${record.id}: ${session} | Kết quả: ${result} | Dự đoán: ${prediction} ${record.win ? '✅ ĐÚNG' : '❌ SAI'}`);
        
        return record;
    }

    // ====== LẤY STATE ======
    getState(results, idx) {
        const slice = results.slice(idx, idx + 10);
        if (slice.length < 10) return null;
        
        const pattern = slice.map(r => r === 'TAI' ? 1 : 0).join('');
        const taiCount = slice.filter(r => r === 'TAI').length;
        const streak = helpers.getStreak(slice);
        
        return `${pattern}_${taiCount}_${streak}`;
    }

    // ====== LẤY DỮ LIỆU ======
    async fetchData() {
        try {
            const res = await fetch(this.url);
            return await res.json();
        } catch (e) {
            console.error('❌ Lỗi fetch:', e.message);
            return null;
        }
    }

    // ====== TRAIN AI ======
    async train() {
        console.log('🧠 Đang train AI...');
        
        const data = await this.fetchData();
        if (!data || !data.list || data.list.length < 20) {
            console.log('❌ Không đủ dữ liệu!');
            return false;
        }

        const results = data.list.map(i => i.resultTruyenThong);
        let trained = 0;

        for (let i = 0; i < results.length - 11; i++) {
            const state = this.getState(results, i);
            if (!state) continue;

            const action = results[i + 10];
            const nextState = this.getState(results, i + 1);

            if (!this.qTable[state]) {
                this.qTable[state] = { TAI: 0, XIU: 0 };
            }
            if (nextState && !this.qTable[nextState]) {
                this.qTable[nextState] = { TAI: 0, XIU: 0 };
            }

            const maxNext = nextState ? Math.max(
                this.qTable[nextState].TAI,
                this.qTable[nextState].XIU
            ) : 0;

            const currentQ = this.qTable[state][action] || 0;
            this.qTable[state][action] = currentQ +
                this.alpha * (1 + this.gamma * maxNext - currentQ);

            trained++;
        }

        this.trained = true;
        console.log(`✅ Train xong! ${trained} mẫu, ${Object.keys(this.qTable).length} states`);
        return true;
    }

    // ====== DỰ ĐOÁN ======
    async predict() {
        if (!this.trained) {
            await this.train();
        }

        const data = await this.fetchData();
        if (!data || !data.list || data.list.length === 0) {
            return this.getFallbackPrediction();
        }

        const current = data.list[0];
        const results = data.list.map(i => i.resultTruyenThong);
        
        // Lấy kết quả game thực tế
        let dice = [3, 4, 5];
        let total = 12;
        let result = 'TAI';
        
        if (current?.detail && current.detail.length === 3) {
            dice = current.detail.map(d => parseInt(d));
            total = dice.reduce((a, b) => a + b, 0);
            result = total >= 11 ? 'TAI' : 'XIU';
        }

        // AI dự đoán
        const state = this.getState(results, 0);
        let prediction = 'TAI';
        let confidence = 50;
        
        if (state && this.qTable[state]) {
            const q = this.qTable[state];
            
            // Exploration vs Exploitation
            if (Math.random() < this.epsilon) {
                prediction = Math.random() < 0.5 ? 'TAI' : 'XIU';
                confidence = 50;
            } else {
                prediction = q.TAI > q.XIU ? 'TAI' : 'XIU';
                const totalQ = q.TAI + q.XIU;
                confidence = totalQ > 0 ? (Math.max(q.TAI, q.XIU) / totalQ * 100) : 50;
            }
        }

        const session = current?.sessionId || helpers.generateSessionId();
        const time = current?.createdAt || helpers.formatTime(new Date());
        const confidenceRounded = Math.round(confidence * 10) / 10;

        // LƯU KẾT QUẢ GAME VÀO LỊCH SỬ
        this.addGameResult(session, dice, total, result, prediction, confidenceRounded);

        return {
            session: session,
            time: time,
            dice: dice,
            total: total,
            result: result,
            prediction: prediction,
            confidence: confidenceRounded
        };
    }

    // ====== FALLBACK ======
    getFallbackPrediction() {
        const dice = helpers.randomDice();
        const total = dice.reduce((a, b) => a + b, 0);
        const result = total >= 11 ? 'TAI' : 'XIU';
        const prediction = total >= 11 ? 'XIU' : 'TAI';
        const session = helpers.generateSessionId();
        const time = helpers.formatTime(new Date());

        this.addGameResult(session, dice, total, result, prediction, 50);

        return {
            session: session,
            time: time,
            dice: dice,
            total: total,
            result: result,
            prediction: prediction,
            confidence: 50
        };
    }

    // ====== LẤY LỊCH SỬ ======
    getHistory(limit = null) {
        if (limit) {
            return this.history.slice(-limit).reverse();
        }
        return this.history.slice().reverse();
    }

    // ====== THỐNG KÊ ======
    getStats() {
        const total = this.history.length;
        const wins = this.history.filter(h => h.win).length;
        const losses = total - wins;
        const accuracy = total > 0 ? (wins / total * 100) : 0;
        
        const taiGames = this.history.filter(h => h.result === 'TAI').length;
        const xiuGames = this.history.filter(h => h.result === 'XIU').length;
        const taiWin = this.history.filter(h => h.result === 'TAI' && h.win).length;
        const xiuWin = this.history.filter(h => h.result === 'XIU' && h.win).length;

        return {
            totalGames: total,
            wins: wins,
            losses: losses,
            accuracy: Math.round(accuracy * 10) / 10,
            result: {
                tai: {
                    total: taiGames,
                    win: taiWin,
                    accuracy: taiGames > 0 ? Math.round(taiWin / taiGames * 100 * 10) / 10 : 0
                },
                xiu: {
                    total: xiuGames,
                    win: xiuWin,
                    accuracy: xiuGames > 0 ? Math.round(xiuWin / xiuGames * 100 * 10) / 10 : 0
                }
            }
        };
    }

    // ====== XÓA LỊCH SỬ ======
    clearHistory() {
        this.history = [];
        this.saveHistory();
        console.log('🗑️ Đã xóa toàn bộ lịch sử game');
        return true;
    }
}

module.exports = TaiXiuAI;
EOF