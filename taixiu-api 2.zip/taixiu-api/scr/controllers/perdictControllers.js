cat > src/controllers/predictController.js << 'EOF'
// =====================================================
//      PREDICT CONTROLLER
// =====================================================

const TaiXiuAI = require('../ai/TaiXiuAI');

let aiInstance = null;

const getAI = () => {
    if (!aiInstance) {
        aiInstance = new TaiXiuAI();
        // Auto train khi khởi tạo
        aiInstance.train().then(() => {
            console.log('✅ AI đã sẵn sàng!');
        });
    }
    return aiInstance;
};

// ====== DỰ ĐOÁN ======
const predict = async (req, res) => {
    try {
        const ai = getAI();
        const result = await ai.predict();
        res.json(result);
    } catch (error) {
        res.status(500).json({ 
            error: 'Lỗi dự đoán',
            message: error.message 
        });
    }
};

// ====== LẤY LỊCH SỬ ======
const getHistory = (req, res) => {
    try {
        const ai = getAI();
        const limit = req.query.limit ? parseInt(req.query.limit) : 20;
        const history = ai.getHistory(limit);
        res.json({
            total: ai.history.length,
            limit: limit,
            data: history
        });
    } catch (error) {
        res.status(500).json({ 
            error: 'Lỗi lấy lịch sử',
            message: error.message 
        });
    }
};

// ====== LẤY TOÀN BỘ LỊCH SỬ ======
const getAllHistory = (req, res) => {
    try {
        const ai = getAI();
        const history = ai.getHistory(null);
        res.json({
            total: ai.history.length,
            data: history
        });
    } catch (error) {
        res.status(500).json({ 
            error: 'Lỗi lấy lịch sử',
            message: error.message 
        });
    }
};

// ====== THỐNG KÊ ======
const getStats = (req, res) => {
    try {
        const ai = getAI();
        const stats = ai.getStats();
        res.json(stats);
    } catch (error) {
        res.status(500).json({ 
            error: 'Lỗi thống kê',
            message: error.message 
        });
    }
};

// ====== XÓA LỊCH SỬ ======
const clearHistory = (req, res) => {
    try {
        const ai = getAI();
        ai.clearHistory();
        res.json({ 
            success: true, 
            message: 'Đã xóa toàn bộ lịch sử game' 
        });
    } catch (error) {
        res.status(500).json({ 
            error: 'Lỗi xóa lịch sử',
            message: error.message 
        });
    }
};

// ====== HEALTH CHECK ======
const health = (req, res) => {
    const ai = getAI();
    res.json({ 
        status: 'OK', 
        trained: ai.trained,
        totalGames: ai.history.length,
        timestamp: new Date().toISOString()
    });
};

module.exports = {
    predict,
    getHistory,
    getAllHistory,
    getStats,
    clearHistory,
    health
};
EOF