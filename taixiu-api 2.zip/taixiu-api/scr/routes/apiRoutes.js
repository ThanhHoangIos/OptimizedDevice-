cat > src/routes/apiRoutes.js << 'EOF'
// =====================================================
//      API ROUTES
// =====================================================

const express = require('express');
const router = express.Router();
const controller = require('../controllers/predictController');

// ====== ROUTES ======

// Dự đoán
router.get('/predict', controller.predict);

// Lịch sử
router.get('/history', controller.getHistory);
router.get('/history/all', controller.getAllHistory);

// Thống kê
router.get('/stats', controller.getStats);

// Xóa lịch sử
router.delete('/history', controller.clearHistory);

// Health check
router.get('/health', controller.health);

// Root
router.get('/', (req, res) => {
    res.json({
        name: 'Tài Xỉu Prediction API',
        version: '2.0.0',
        features: {
            'Lưu kết quả': 'Mỗi ván game được lưu vào lịch sử'
        },
        endpoints: {
            '/api/predict': 'GET - Dự đoán và lưu kết quả game',
            '/api/history': 'GET - Lịch sử game (limit=20)',
            '/api/history/all': 'GET - Toàn bộ lịch sử game',
            '/api/stats': 'GET - Thống kê game',
            '/api/health': 'GET - Health check'
        }
    });
});

module.exports = router;
EOF