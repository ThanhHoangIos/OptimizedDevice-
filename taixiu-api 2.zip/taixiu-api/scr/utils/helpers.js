cat > src/utils/helpers.js << 'EOF'
// =====================================================
//      HELPER FUNCTIONS
// =====================================================

module.exports = {
    // Lấy streak (chuỗi liên tiếp)
    getStreak(arr) {
        let streak = 1;
        let type = arr[0];
        for (let i = 1; i < arr.length; i++) {
            if (arr[i] === type) streak++;
            else break;
        }
        return streak;
    },

    // Random 3 viên xúc sắc
    randomDice() {
        return [
            Math.floor(Math.random() * 6) + 1,
            Math.floor(Math.random() * 6) + 1,
            Math.floor(Math.random() * 6) + 1
        ];
    },

    // Tạo mã phiên
    generateSessionId() {
        const now = new Date();
        const date = now.toISOString().slice(2, 10).replace(/-/g, '');
        const time = now.toISOString().slice(11, 13) + now.toISOString().slice(14, 16);
        return date + time;
    },

    // Format thời gian
    formatTime(date) {
        return date.toISOString().replace('T', ' ').slice(0, 19);
    },

    // Sleep
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
};
EOF