// =====================================================
//      MAIN SERVER - ĐỌC env.txt
// =====================================================

// Đọc file env.txt thay vì .env
const dotenv = require('dotenv');
dotenv.config({ path: './env.txt' });

const express = require('express');
const cors = require('cors');
const apiRoutes = require('./src/routes/apiRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api', apiRoutes);

// 404 handler
app.use((req, res) => {
    res.status(404).json({
        error: 'Không tìm thấy endpoint',
        path: req.path
    });
});

// Error handler
app.use((err, req, res, next) => {
    console.error('❌ Error:', err);
    res.status(500).json({
        error: 'Lỗi server',
        message: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
});

// Start server
app.listen(PORT, () => {
    console.log('═══════════════════════════════════════════');
    console.log(`  🎲 TÀI XỈU PREDICTION API`);
    console.log(`  📡 PORT: ${PORT}`);
    console.log(`  📂 Lưu kết quả game: CÓ`);
    console.log('═══════════════════════════════════════════');
    console.log('\n📋 Endpoints:');
    console.log(`   GET  /api/predict       - Dự đoán + Lưu game`);
    console.log(`   GET  /api/history       - Lịch sử game`);
    console.log(`   GET  /api/history/all   - Toàn bộ game`);
    console.log(`   GET  /api/stats         - Thống kê game`);
    console.log(`   DELETE /api/history     - Xóa lịch sử`);
    console.log(`   GET  /api/health        - Health check`);
    console.log('\n🚀 Server sẵn sàng!');
    console.log(`🔗 http://localhost:${PORT}/api/predict\n`);
});

module.exports = app;